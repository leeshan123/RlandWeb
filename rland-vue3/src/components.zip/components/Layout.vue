<script setup>
import Header from "./Header.vue"
import Footer from "./Footer.vue"
</script>


<template>
    <Header />
    레이아웃
    <Footer />
</template>